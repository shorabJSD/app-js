const openEl = document.getElementById("open");
const navbarEl = document.getElementById("navbar");
const closeEl = document.getElementById("close");

function openClose(){
   openEl.addEventListener("click", ()=>{
    navbarEl.classList.add("active");
   })

   closeEl.addEventListener("click", ()=>{
    navbarEl.classList.remove("active")
   });

}
openClose();

// navbar background color change ;
const headerEl = document.getElementById("header");
const demoEl = document.getElementById("demo");


window.addEventListener("scroll",()=>{
    if (window.scrollY >= demoEl.scrollHeight ) {
        headerEl.classList.add("active");
    } else {
        headerEl.classList.remove("active");
    }
})









